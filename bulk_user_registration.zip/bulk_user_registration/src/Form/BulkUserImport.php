<?php

namespace Drupal\bulk_user_registration\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\bulk_user_registration\Services\Import;


/**
 * Configure Content Import settings for this site.
 */
class BulkUserImport extends FormBase {


 /**
   * @var Import $Import
   */
  protected $import;

  /**
   * Class constructor.
   */
  public function __construct(Import $import) {
    $this->import = $import;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
      // Load the service required to construct this class.
      $container->get('csv.demo')
    );
  }


  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bulk_user_registration';
  }

  /**
   * User Import Form.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
	  

   $form = array(); 
  $form['browser'] = array(
    '#type' => 'fieldset', 
    '#title' => t('Browser Upload'), 
    '#collapsible' => TRUE, 
    '#description' => t("Upload a CSV file."), 
  ); 
  $file_size = t('Maximum file size: !size MB.', array('!size' => file_upload_max_size()));
  $form['browser']['file_upload'] = array( 
    '#type' => 'file', 
    '#title' => t('CSV File'), 
    '#size' => 40, 
    '#description' => t('Select the CSV file to be imported. ') . $file_size
  ); 
  $form['submit'] = array( '#type' => 'submit', '#value' => t('Save'), ); 
  // set the form encoding type 
  $form['#attributes']['enctype'] = "multipart/form-data"; 
  return $form; 
   
  }


public function validateForm(array &$form, FormStateInterface $form_state) {
	
	 $file = file_save_upload('file_upload'); 
  // check file uploaded OK 
  if (!$file) { 
    form_set_error('file_upload', t('A file must be uploaded or selected from FTP updates.')); 
  } 
  else if($file->filemime != 'text/csv') { 
    form_set_error('file_upload', t('The file must be of CSV type only.')); 
  } 
  else { 
  // set files to form_state, to process when form is submitted 
    $form_state['values']['file_upload'] = $file; 
  } 
}

public function submitForm(array &$form, FormStateInterface $form_state) {
 
 return[
'#markup' => $this->import->import()
 ];

}
}

 
  



  

?>