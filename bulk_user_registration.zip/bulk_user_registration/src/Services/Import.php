<?php
namespace Drupal\bulk_user_registration\Services;
use Drupal\file\Entity\File;
use Symfony\Component\HttpFoundation\RedirectResponse;

class Import{
	
public  function import(){

$line_max = variable_get('user_import_line_max', 1000);
  ini_set('auto_detect_line_endings', true);
  $filepath = $form_state['values']['file_upload']->filepath;
  $handle = @fopen($filepath, "r");
  // start count of imports for this upload
  $send_counter = 0;
  
  $query = \Drupal::entityQuery('user');
$uids = $query->execute();

  while ($row = fgetcsv($handle, $line_max, ',')) {
  foreach($row as $key=>$value) {
	  
	 $ids = \Drupal::entityQuery('user')->condition('name', $row[0])->range(0, 1)->execute();
	 
    if(!empty($ids)){
     $pids = \Drupal::entityQuery('payroll')->condition('name', $row[0])->range(0, 1)->execute();
	 if(empty($ids)){
	$payroll = \Drupal::entityTypeManager()->getStorage('payroll')->create(['type' => 'payroll ','id'=> $row[0],'basic_salary' => $row[1],'hra' => $row[2],'medical_allowance' => $row[3],'professional_tax'=>$row[4],'total_salary'=>row[5]]);
    }
  }
  }
}
 return new RedirectResponse(\Drupal::url('content_entity_example_employee.collection'));
}  
?>	  