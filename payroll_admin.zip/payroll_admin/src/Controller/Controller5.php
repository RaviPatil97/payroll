<?php

/**
 * @file
 * Contains \Drupal\payroll_admin\Controller\Controller5.
 */
namespace Drupal\payroll_admin\Controller;

use Drupal\Core\Controller\ControllerBase;

class Controller5 extends ControllerBase {
  public function content() {
   return new RedirectResponse(\Drupal::url('http://localhost/drupal-8.6.10/admin/people/create'));
  }
}