<?php

/**
 * @file
 * Contains \Drupal\payroll_admin\Controller\Controller2.
 */
namespace Drupal\payroll_admin\Controller;

use Drupal\Core\Controller\ControllerBase;

class Controller2 extends ControllerBase {
  public function content() {
    return array(
      '#type' => 'markup',
      '#markup' => $this->t('Hello World'),
    );
  }
}