<?php

namespace Drupal\payroll\Entity\Controller;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Url;

/**
 * Provides a list controller for payroll entity.
 *
 * @ingroup payroll
 */
class PayrollListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   *
   * We override ::render() so that we can add our own content above the table.
   * parent::render() is where EntityListBuilder creates the table using our
   * buildHeader() and buildRow() implementations.
   */
  public function render() {
    $build['description'] = [
      '#markup' => $this->t('Payroll Entity implements a Payroll model. These contacts are fieldable entities. You can manage the fields on the <a href="@adminlink">Contacts admin page</a>.', array(
        '@adminlink' => \Drupal::urlGenerator()
          ->generateFromRoute('payroll.settings'),
      )),
    ];

    $build += parent::render();
    return $build;
  }

  /**
   * {@inheritdoc}
   *
   * Building the header and content lines for the contact list.
   *
   * Calling the parent::buildHeader() adds a column for the possible actions
   * and inserts the 'edit' and 'delete' links as defined for the entity type.
   */
  public function buildHeader() {
    $header['employee_no'] = $this->t('Employee No');
    $header['name'] = $this->t('Name');
    $header['username'] = $this->t('Username');
	$header['hra'] = $this->t('HRA');
	$header['basic_sal'] = $this->t('Basic Salary');
	$header['medical_allowance'] = $this->t('Medical Allowance');
	$header['professional_tax'] = $this->t('Professional Tax');
	$header['total_sal'] = $this->t('Total Salary');
    
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var $entity \Drupal\payroll\Entity\payroll */
    $row['employee_no'] = $entity->employee_no->value;
    $row['name'] = $entity->name->value;
	$row['username'] = $entity->link();;
	$row['hra'] = $entity->hra->value;
	$row['basic_sal'] = $entity->basic_sal->value;
	$row['medical_allowance'] = $entity->medical_allowance->value;
	$row['professional_tax'] = $entity->professional_tax->value;
	$row['total_sal'] = $entity->total_sal->value;
	
    return $row + parent::buildRow($entity);
  }

}
?>