<?php

namespace Drupal\csv_importer\Plugin\Importer;

use Drupal\csv_importer\Plugin\ImporterBase;

/**
 * Class ContactImporter.
 *
 * @Importer(
 *   id = "contact_importer",
 *   entity_type = "contact",
 *   label = @Translation("User importer")
 * )
 */
class ContactImporter extends ImporterBase {}
