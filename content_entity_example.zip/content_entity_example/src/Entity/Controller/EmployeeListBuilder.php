<?php

namespace Drupal\content_entity_example\Entity\Controller;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Url;

/**
 * Provides a list controller for content_entity_example_employee entity.
 *
 * @ingroup content_entity_example
 */
class EmployeeListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   *
   * We override ::render() so that we can add our own content above the table.
   * parent::render() is where EntityListBuilder creates the table using our
   * buildHeader() and buildRow() implementations.
   */
  public function render() {
    $build['description'] = [
      '#markup' => $this->t('Content Entity Example implements a Employees model. These employees are fieldable entities. You can manage the fields on the <a href="@adminlink">Employees admin page</a>.', array(
        '@adminlink' => \Drupal::urlGenerator()
          ->generateFromRoute('content_entity_example.employee_settings'),
      )),
    ];

    $build += parent::render();
    return $build;
  }

  /**
   * {@inheritdoc}
   *
   * Building the header and content lines for the contact list.
   *
   * Calling the parent::buildHeader() adds a column for the possible actions
   * and inserts the 'edit' and 'delete' links as defined for the entity type.
   */
  public function buildHeader() {
	$header['Username'] = $this->t('Username');
    $header['Employee No'] = $this->t('Employee No');
	$header['name'] = $this->t('Name');
	$header['hra'] = $this->t('HRA');
	$header['basic_sal'] = $this->t('Basic Salary');
	$header['medical_allowance'] = $this->t('Medical Allowance');
	$header['professional_tax'] = $this->t('Professional Tax');
	$header['total_sal'] = $this->t('Total Salary');
    
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var $entity \Drupal\content_entity_example\Entity\Employee */
	$row['username'] = $entity->field_username->value;
    $row['employee_no'] = $entity->field_e->value;
    $row['name'] = $entity->field_name->value;
	$row['hra'] = $entity->field_hra->value;
	$row['basic_sal'] = $entity->field_b->value;
	$row['medical_allowance'] = $entity->field_m->value;
	$row['professional_tax'] = $entity->field_p->value;
	$row['total_sal'] = $entity->field_t->value;
	
    return $row + parent::buildRow($entity);
  }

}
?>